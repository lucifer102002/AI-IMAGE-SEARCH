const apiKey = 'qA5znZvKNYatDg0PycC2b4Q-hdSc8Pertdn-kWPLMU0';
const searchInput = document.getElementById('search');
const searchButton = document.getElementById('search-button');
const gallery = document.getElementById('gallery');
const loadMoreButton = document.getElementById('load-more-button');

let currentPage = 1;
let currentQuery = '';

searchButton.addEventListener('click', () => {
    searchImages();
});

searchInput.addEventListener('keypress', (event) => {
    if (event.key === 'Enter') {
        searchImages();
    }
});

loadMoreButton.addEventListener('click', () => {
    currentPage++;
    fetchImages(currentQuery, currentPage);
});

function searchImages() {
    currentQuery = searchInput.value;
    if (currentQuery) {
        currentPage = 1;
        fetchImages(currentQuery, currentPage);
    }
}

async function fetchImages(query, page) {
    const url = `https://api.unsplash.com/search/photos?query=${query}&page=${page}&client_id=${apiKey}`;
    const response = await fetch(url);
    const data = await response.json();
    if (page === 1) {
        gallery.innerHTML = '';
    }
    displayImages(data.results);
    if (data.total_pages > page) {
        loadMoreButton.style.display = 'block';
    } else {
        loadMoreButton.style.display = 'none';
    }
}

function displayImages(images) {
    images.forEach(image => {
        const imgElement = document.createElement('div');
        imgElement.classList.add('image-container');
        imgElement.innerHTML = `
      <img src="${image.urls.small}" alt="${image.alt_description}">
      <button class="download-button" onclick="downloadImage('${image.urls.full}')">Download</button>
    `;
        gallery.appendChild(imgElement);
    });
}

function downloadImage(url) {
    const a = document.createElement('a');
    a.href = url;
    a.download = '';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}